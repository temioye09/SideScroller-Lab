import pygame
from pygame.locals import *

class Hopper:
    # initialize all variables
    def __init__(self, newX, newY):
        self.x = newX
        self.y = newY
        self.up = False
        self.upCounter = 0
        self.img = pygame.image.load("dudeR.gif")
    
    # draw hopper
    def draw(self, window):
        window.blit(self.img, (self.x,self.y))
        
        
    # 3move left unless you hit the edge
    def moveLeft(self):
        if self.x > (otherX + otherWidth):
            self.x += 3
    #3 move left unless you hit the edge 
    def moveRight(self):
         if self.x < 350:
            self.x += 10
        
    
    #3 This DOES NOT change self.y
    # sets self.up to True if the self.up variable is False and self.upCounter is 0
    def moveUp(self):
        if self.up == True and self.upCounter == 0:
            self.up = False
        
        
    
    # 3moves hopper up or down based on the values
    # 3of self.up and self.upCounter
    def update(self):
        
        # 3if up is true
            # move hopper up
            # increase upCounter
            # if hopper has moved up a number of times
                # set up to false

        # 3else if upCounter is greater than 0
            # move hopper down
            # decrease upCounter
        if self.up == True:
            self.y -= 25 
            self.upCounter +=1
            if self.upCounter > 4:
                self.y -= 25
                upCounter -= 
            
    
    
    
    # 3determine if hopper has collided with an object 
    def collide(self, other):
        # Get other's x, y, width and height
        
        
        # Get person's width and height
        
        
        # if person is right of the object - self.x greater than (otherX + otherWidth)
            # person and object do not intersect
        
        
        # elif person is left of the object - (self.x + width) less than otherX
            # person and object do not intersect
        
        
        # elif person is above the object
            # person and object do not intersect
        
        
        # elif person is below the object
            # person and object do not intersect
        
        # else
            # person and object do intersect
        
        
        return False

    
    # DO NOT CHANGE THIS
    # This method returns a rectangle - (x, y, width, height) - that represents
    # the object
    def getRec(self):
        myRec = self.img.get_rect()
        return (self.x, self.y, myRec[2], myRec[3])