import pygame
from pygame.locals import *

class Person:
    #1 set all class variables in the constructor
    def __init__(self, newX, newY):
        self.img = pygame.image.load("dude.gif")
        self.x = newX
        self.y = newY
        
    #1 draw your image
    def draw(self, window):
        window.blit(self.img,(self.x,self.y))
    
    #1 move left unless you hit the edge
    def moveLeft(self):
        if self.x > 0 and self.x < 400:
            self.x -= 5
        else:
            self.x = 1
    #1 move right unless you hit the edge
    def moveRight(self):
        if self.x < 350:
            self.x += 10
        
        
    #1 move up unless you hit the edge
    def moveUp(self):
        if self.y > 0 and self.y < 400:
            self.y -= 5
        else:
            self.y = 1
    
        
    #1 move down unless you hit the edge
    def moveDown(self):
        if self.y < 350:
            self.y += 10
        
        
        
    
    
    # This will be filled out in 2.ifs_collide_lab. 
    # It will return True if your person has 
    # collided with another object
    def collide(self, other):
        otherRec = other.getRec()
        otherX = otherRec[0]
        otherY = otherRec[1]
        otherWidth = otherRec[2]
        otherHeight = otherRec[3]
        
        
        
        
        #2 Get person's width and height
        personRec = self.getRec()
        personWidth = personRec[2]
        personHeight = personRec[3]        
        
        #2 check if person is to the right of the object
        #2 if self.x greater than (otherX + otherWidth)
            # person and object do not intersect
        if self.x > (otherX + otherWidth):
            return False 
        
        #2 else check if the person is to the left of the object
        # elif(self.x + width) less than otherX
            # person and object do not intersect
        elif(self.x + personWidth) < otherX:
            return False

            
        
        
        #2 elif person is above the object
            # person and object do not intersect
        elif (self.y) > (otherHeight + otherY):
            return False
        
        
        #2 elif person is below the object
            # person and object do not intersect
        elif (self.y + personHeight) < otherY:
            return False
        
        
        #2 else
            # person and object do intersect
    
        else: 
            return True
        

    
    # DO NOT CHANGE THIS
    # This method returns a rectangle - (x, y, width, height) - that represents
    # the object
    def getRec(self):
        myRec = self.img.get_rect()
        return (self.x, self.y, myRec[2], myRec[3])